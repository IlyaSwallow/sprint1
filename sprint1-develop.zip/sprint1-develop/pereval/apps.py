from django.apps import AppConfig


class PerevalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pereval'
