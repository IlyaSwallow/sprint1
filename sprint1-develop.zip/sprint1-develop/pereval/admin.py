from django.contrib import admin
from .models import *


admin.site.register(User)
admin.site.register(Image)
admin.site.register(Pereval)
admin.site.register(Coords)
admin.site.register(Level)
